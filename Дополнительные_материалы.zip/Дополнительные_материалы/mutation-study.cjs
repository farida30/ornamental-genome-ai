// Additional automated sensitivity study, 27 September 2026.
// This script was prepared and executed with AI assistance; it is not evidence of independent student execution.
const fs=require('fs'),path=require('path'),E=require('./engine/engine.js');
const seeds=[1692026,2702026,3802026],motifs=[0,4,10],mus=[.1,.25,.5],N=6,G=3;
const locks={frameShape:2,compositionType:0,palette:0,rotation:0,orientation:0};
const ints=new Set(['mirror','repeat','pairing','rhythm','orientation','compositionType','palette','frameShape']);
function randomGenome(main,r){let g=E.base(main);for(const [k,[lo,hi]] of Object.entries(E.ranges(main,'free'))){g[k]=ints.has(k)?Math.round(lo+(hi-lo)*r()):Math.round((lo+(hi-lo)*r())*1000)/1000;}Object.assign(g,locks);return E.normalize(g,'free');}
function rec(g,id){return{id,g,identity:E.identity(g)}}
let all=[],summary=[];
for(const main of motifs)for(const seed of seeds){const r0=E.rng(seed),initial=Array.from({length:N},(_,j)=>rec(randomGenome(main,r0),'I'+j));
 for(const mu of mus){let evo=initial.map(x=>structuredClone(x)),control=initial.map(x=>structuredClone(x));const re=E.rng(seed+991),rc=E.rng(seed+991);let generations=[{generation:0,evo,control}];
 for(let t=1;t<=G;t++){const parents=[...evo].sort((a,b)=>b.identity.score-a.identity.score||a.id.localeCompare(b.id)).slice(0,2);evo=Array.from({length:N},(_,j)=>{const c=E.cross(parents,re,'free',mu,locks);return {...rec(c.g,'E'+t+'-'+j),lineage:c}});control=Array.from({length:N},(_,j)=>rec(randomGenome(main,rc),'R'+t+'-'+j));generations.push({generation:t,evo,control});}
 const es=E.stats(evo),rs=E.stats(control);summary.push({motif:E.models[main].name,main,seed,mu,Q_evo:es.mean,D_evo:es.diversity,Q_random:rs.mean,D_random:rs.diversity});all.push({main,seed,mu,generations});}}
const groups=mus.map(mu=>{let rows=summary.filter(x=>x.mu===mu);let out={mu,runs:rows.length};for(let k of ['Q_evo','D_evo','Q_random','D_random'])out[k]=rows.reduce((s,r)=>s+r[k],0)/rows.length;return out});
fs.writeFileSync(path.join(__dirname,'mutation-results.json'),JSON.stringify({engine:E.version,date:'2026-09-27',protocol:{N,G,seeds,motifs,mus,locks,random:'independent uniform sampling then integer rounding; per-branch RNG seed+991 continuous over 3 rounds',selection:'best 2 by Q, tie by id',filters:false},groups,summary,all},null,2));
fs.writeFileSync(path.join(__dirname,'mutation-summary.csv'),Object.keys(summary[0]).join(',')+'\n'+summary.map(x=>Object.values(x).join(',')).join('\n'));
const demo={...E.base(0),curve:1.1,aspect:1.05,strokeWidth:10,core:1,skew:0,asymmetry:0};fs.writeFileSync(path.join(__dirname,'q-example.json'),JSON.stringify({genome:demo,result:E.identity(demo)},null,2));
// A design sample from a recorded experimental descendant.
const sample=all.find(x=>x.main===0&&x.seed===1692026&&x.mu===.25).generations.at(-1).evo.slice().sort((a,b)=>b.identity.score-a.identity.score)[0];
fs.writeFileSync(path.join(__dirname,'design-genome.json'),JSON.stringify(sample,null,2));fs.writeFileSync(path.join(__dirname,'design-sample.svg'),E.svg(sample.g,{transparent:true}));console.log(JSON.stringify({groups,qexample:E.identity(demo)},null,2));
