/* Equal radial modules form the silhouette itself, without an enclosing frame.
   The same parametric placements drive preview and export. */
(function(root){'use strict';
const names=['Свободная','Ромб','Круг','Квадрат','Лента','Шестиугольник','Восьмиугольник'];
function shape(id){
 let vertices=null,radius=null;
 if(id===1)vertices=[[400,35],[735,280],[400,525],[65,280]];
 if(id===2)radius=235;
 if(id===3)vertices=[[170,50],[630,50],[630,510],[170,510]];
 if(id===4)vertices=[[45,135],[755,135],[755,425],[45,425]];
 if(id===5||id===6){let n=id===5?6:8;vertices=Array.from({length:n},(_,i)=>{let a=-Math.PI/2+i*2*Math.PI/n;return[400+235*Math.cos(a),280+235*Math.sin(a)]})}
 const inside=(x,y)=>{if(radius)return Math.hypot(x-400,y-280)<=radius-9;if(!vertices)return x>=30&&x<=770&&y>=30&&y<=530;return vertices.every((a,i)=>{let b=vertices[(i+1)%vertices.length];return (b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0])>=9*Math.hypot(b[0]-a[0],b[1]-a[1])})};
 const path=radius?`M635 280 A235 235 0 1 1 165 280 A235 235 0 1 1 635 280 Z`:vertices?'M'+vertices.map(p=>p.map(v=>v.toFixed(2)).join(' ')).join(' L')+' Z':'';
 return{id,vertices,radius,path,inside};
}
function layout(g,w,h){
 const id=g.frameShape||0,s=shape(id),items=[];
 // Equal modules share one rotational centre; no central stamp or satellites.
 const count=id===5?6:id===6?8:id===4?Math.max(2,g.repeat||3):4;
 if(id===4){const size=Math.min(650/(count*w*.88),320/h);for(let i=0;i<count;i++)items.push({x:400+(i-(count-1)/2)*w*size*.88,y:280,size,angle:i%2?180:0});}
 else{
   const offset=id===3?45:0;
   const radiusPerUnit=Math.max(h*.43,w*.44/Math.tan(Math.PI/count));
   let size=225/(radiusPerUnit+h*.5),radius=radiusPerUnit*size;
   // Fit the whole rotated composition at once, preserving equal motif sizes.
   const raw=[];
   for(let i=0;i<count;i++){let angle=offset+i*360/count+(g.rotation||0),a=angle*Math.PI/180,x=Math.sin(a)*radius,y=-Math.cos(a)*radius;raw.push({x,y,size,angle});}
   let maxX=0,maxY=0;
   for(const p of raw){const a=p.angle*Math.PI/180,c=Math.abs(Math.cos(a)),sn=Math.abs(Math.sin(a));maxX=Math.max(maxX,Math.abs(p.x)+(w*c+h*sn)*size/2);maxY=Math.max(maxY,Math.abs(p.y)+(w*sn+h*c)*size/2);}
   const fit=Math.min(g.scale||1,340/maxX,240/maxY),stretch=id===1?1.22:1;
   for(const p of raw)items.push({x:400+p.x*fit*stretch,y:280+p.y*fit,size:p.size*fit,angle:p.angle});
 }
 return{...s,items};
}
const api={names,shape,layout};if(typeof module!=='undefined')module.exports=api;else root.OGGeometry=api;
})(typeof window!=='undefined'?window:this);
